#!/usr/bin/env bash
#
# Spin up a local kind cluster, install Istio, and deploy the MLflow chart
# for end-to-end testing.
#
# Usage:
#   ./scripts/deploy-local.sh            # deploy with helm (default)
#   USE_TERRAFORM=1 ./scripts/deploy-local.sh   # deploy via terraform instead
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

CLUSTER_NAME="mlflow"
NAMESPACE="mlflow"
RELEASE="mlflow"
HOST="mlflow.local"
CHART_DIR="${ROOT_DIR}/charts/mlflow"
USE_TERRAFORM="${USE_TERRAFORM:-0}"

log() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }

require() {
  command -v "$1" >/dev/null 2>&1 || { echo "ERROR: '$1' is required but not installed."; exit 1; }
}

require kind
require kubectl
require helm
require istioctl

# ---------------------------------------------------------------------------
log "Creating kind cluster '${CLUSTER_NAME}' (if it doesn't exist)"
if ! kind get clusters | grep -qx "${CLUSTER_NAME}"; then
  kind create cluster --config "${SCRIPT_DIR}/kind-cluster.yaml"
else
  echo "kind cluster '${CLUSTER_NAME}' already exists; reusing it."
fi
kubectl config use-context "kind-${CLUSTER_NAME}"

# ---------------------------------------------------------------------------
log "Installing Istio (ingress gateway exposed via NodePort)"
cat <<'EOF' | istioctl install -y -f -
apiVersion: install.istio.io/v1alpha1
kind: IstioOperator
spec:
  profile: default
  components:
    ingressGateways:
      - name: istio-ingressgateway
        enabled: true
        k8s:
          service:
            type: NodePort
            ports:
              - name: status-port
                port: 15021
                targetPort: 15021
                nodePort: 30021
              - name: http2
                port: 80
                targetPort: 8080
                nodePort: 30080
              - name: https
                port: 443
                targetPort: 8443
                nodePort: 30443
EOF

# ---------------------------------------------------------------------------
log "Preparing namespace '${NAMESPACE}' with sidecar injection"
kubectl create namespace "${NAMESPACE}" --dry-run=client -o yaml | kubectl apply -f -
kubectl label namespace "${NAMESPACE}" istio-injection=enabled --overwrite

# ---------------------------------------------------------------------------
if [ "${USE_TERRAFORM}" = "1" ]; then
  require terraform
  log "Deploying MLflow via Terraform"
  terraform -chdir="${ROOT_DIR}/terraform" init -input=false
  terraform -chdir="${ROOT_DIR}/terraform" apply -input=false -auto-approve \
    -var="local_test=true" \
    -var="kube_context=kind-${CLUSTER_NAME}" \
    -var="namespace=${NAMESPACE}"
else
  log "Deploying MLflow via Helm (values-local.yaml)"
  helm upgrade --install "${RELEASE}" "${CHART_DIR}" \
    --namespace "${NAMESPACE}" \
    -f "${CHART_DIR}/values-local.yaml" \
    --wait --timeout 5m
fi

# ---------------------------------------------------------------------------
log "Waiting for the MLflow deployment to become available"
kubectl -n "${NAMESPACE}" rollout status deploy/"${RELEASE}" --timeout=300s

# ---------------------------------------------------------------------------
log "Smoke test: /health via the Istio ingress gateway"
sleep 5
if curl -fsS -H "Host: ${HOST}" http://localhost:8080/health >/dev/null; then
  echo "OK: MLflow is reachable."
else
  echo "WARN: health check did not pass yet. It may need a few more seconds."
fi

cat <<EOF

------------------------------------------------------------------
MLflow is deployed on kind cluster '${CLUSTER_NAME}'.

Map the host locally, then browse http://${HOST}:8080 :
  echo '127.0.0.1 ${HOST}' | sudo tee -a /etc/hosts

Login (basic-auth) -> username: admin  password: password
The MLflow UI shows the logged-in user; manage users at /signup.

Log a run against it (with credentials):
  export MLFLOW_TRACKING_URI=http://${HOST}:8080
  export MLFLOW_TRACKING_USERNAME=admin
  export MLFLOW_TRACKING_PASSWORD=password
  python -c "import mlflow; mlflow.set_experiment('demo'); mlflow.start_run(); mlflow.log_metric('m', 1.0); mlflow.end_run()"

Tear down when done:
  ./scripts/teardown.sh
------------------------------------------------------------------
EOF
