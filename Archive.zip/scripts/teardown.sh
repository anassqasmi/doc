#!/usr/bin/env bash
# Delete the local kind test cluster.
set -euo pipefail

CLUSTER_NAME="mlflow"

if kind get clusters | grep -qx "${CLUSTER_NAME}"; then
  echo "Deleting kind cluster '${CLUSTER_NAME}'..."
  kind delete cluster --name "${CLUSTER_NAME}"
  echo "Done."
else
  echo "No kind cluster named '${CLUSTER_NAME}' found."
fi
