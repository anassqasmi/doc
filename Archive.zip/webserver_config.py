import os

from airflow.providers.fab.auth_manager.security_manager.override import (
    FabAirflowSecurityManagerOverride,
)
from flask_appbuilder.security.manager import AUTH_OAUTH

AUTH_TYPE = AUTH_OAUTH
AUTH_USER_REGISTRATION = True
AUTH_USER_REGISTRATION_ROLE = os.environ.get("OIDC_DEFAULT_ROLE", "Admin")

OAUTH_PROVIDERS = [
    {
        "name": "oidc",
        "icon": "fa-key",
        "token_key": "access_token",
        "remote_app": {
            "client_id": os.environ["OIDC_CLIENT_ID"],
            "client_secret": os.environ["OIDC_CLIENT_SECRET"],
            "server_metadata_url": os.environ["OIDC_ISSUER_URL"].rstrip("/")
            + "/.well-known/openid-configuration",
            "client_kwargs": {"scope": "openid email profile"},
        },
    }
]


class OidcSecurityManager(FabAirflowSecurityManagerOverride):
    """Maps standard OIDC userinfo claims onto FAB users."""

    def get_oauth_user_info(self, provider, resp=None):
        me = self.appbuilder.sm.oauth_remotes[provider].userinfo()
        return {
            "username": me.get("preferred_username") or me.get("email") or me["sub"],
            "email": me.get("email"),
            "first_name": me.get("given_name", ""),
            "last_name": me.get("family_name", ""),
        }


SECURITY_MANAGER_CLASS = OidcSecurityManager
