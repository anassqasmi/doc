variable "namespace" {
  description = "Existing namespace to deploy Airflow into."
  type        = string
}

variable "release_name" {
  description = "Helm release name."
  type        = string
  default     = "airflow"
}

variable "hostname" {
  description = "Public hostname served by the Istio gateway."
  type        = string
}

variable "istio_gateway" {
  description = "Existing Istio Gateway, as namespace/name."
  type        = string
  default     = "istio-system/public-gateway"
}

variable "oidc_issuer_url" {
  description = "OIDC issuer URL (discovery document is derived from it)."
  type        = string
}

variable "oidc_secret_name" {
  description = "Existing secret holding the OIDC credentials (keys: client-id, client-secret)."
  type        = string
}

variable "oidc_callback_url" {
  description = "Redirect URI registered in the IdP."
  type        = string
  default     = null
}

variable "airflow_image" {
  description = "Airflow image used by every container in the pod."
  type        = string
  default     = "apache/airflow:3.2.2"
}

variable "public_url" {
  description = "Externally visible URL. Defaults to https on the hostname; override for a non-standard scheme or port."
  type        = string
  default     = null
}

locals {
  base_url     = coalesce(var.public_url, "https://${var.hostname}")
  callback_url = coalesce(var.oidc_callback_url, "${local.base_url}/auth/oauth-authorized/oidc")
  db_path      = "/opt/airflow/metadata/airflow.db"

  # An emptyDir cannot be shared between pods, so the scheduler and dag processor
  # run as sidecars of the API server and all three share the SQLite file.
  sidecar = {
    image = var.airflow_image
    env = [
      { name = "AIRFLOW__DATABASE__SQL_ALCHEMY_CONN", valueFrom = { secretKeyRef = { name = kubernetes_secret_v1.metadata_connection.metadata[0].name, key = "connection" } } },
      { name = "AIRFLOW__CORE__FERNET_KEY", valueFrom = { secretKeyRef = { name = "${var.release_name}-fernet-key", key = "fernet-key" } } },
      { name = "AIRFLOW__API_AUTH__JWT_SECRET", valueFrom = { secretKeyRef = { name = "${var.release_name}-jwt-secret", key = "jwt-secret" } } },
    ]
    volumeMounts = [
      { name = "config", mountPath = "/opt/airflow/airflow.cfg", subPath = "airflow.cfg", readOnly = true },
      { name = "metadata-db", mountPath = dirname(local.db_path) },
    ]
  }
}

resource "kubernetes_secret_v1" "metadata_connection" {
  metadata {
    name      = "${var.release_name}-metadata-connection"
    namespace = var.namespace
  }
  data = {
    connection = "sqlite:///${local.db_path}"
  }
}

resource "helm_release" "airflow" {
  name      = var.release_name
  chart     = "${path.module}/chart"
  namespace = var.namespace
  timeout   = 900

  values = [yamlencode({
    # Airflow 3 dropped SequentialExecutor; LocalExecutor is what runs against SQLite.
    executor   = "LocalExecutor"
    images     = { airflow = { repository = split(":", var.airflow_image)[0], tag = split(":", var.airflow_image)[1] } }
    postgresql = { enabled = false }
    redis      = { enabled = false }
    statsd     = { enabled = false }

    data = { metadataSecretName = kubernetes_secret_v1.metadata_connection.metadata[0].name }

    # Metadata DB and logs are pod-local: nothing survives a restart, and logs are
    # scraped from stdout by Cloud Logging.
    volumes      = [{ name = "metadata-db", emptyDir = {} }]
    volumeMounts = [{ name = "metadata-db", mountPath = dirname(local.db_path) }]

    config = {
      api  = { base_url = local.base_url }
      core = { auth_manager = "airflow.providers.fab.auth_manager.fab_auth_manager.FabAuthManager" }
    }

    apiServer = {
      # --proxy-headers makes uvicorn trust X-Forwarded-Proto from the Istio ingress.
      args              = ["bash", "-c", "exec airflow api-server --proxy-headers"]
      waitForMigrations = { enabled = false }
      extraInitContainers = [
        merge(local.sidecar, { name = "db-migrate", args = ["bash", "-c", "airflow db migrate"] }),
      ]
      extraContainers = [
        merge(local.sidecar, { name = "scheduler", args = ["bash", "-c", "exec airflow scheduler"] }),
        merge(local.sidecar, { name = "dag-processor", args = ["bash", "-c", "exec airflow dag-processor"] }),
      ]
      env = [
        { name = "FORWARDED_ALLOW_IPS", value = "*" },
        { name = "OIDC_ISSUER_URL", value = var.oidc_issuer_url },
        { name = "OIDC_CLIENT_ID", valueFrom = { secretKeyRef = { name = var.oidc_secret_name, key = "client-id" } } },
        { name = "OIDC_CLIENT_SECRET", valueFrom = { secretKeyRef = { name = var.oidc_secret_name, key = "client-secret" } } },
      ]
      apiServerConfig = file("${path.module}/webserver_config.py")
    }
  })]
}

resource "kubernetes_manifest" "virtual_service" {
  manifest = {
    apiVersion = "networking.istio.io/v1"
    kind       = "VirtualService"
    metadata = {
      name      = var.release_name
      namespace = var.namespace
    }
    spec = {
      hosts    = [var.hostname]
      gateways = [var.istio_gateway]
      http = [{
        route = [{
          destination = {
            host = "${var.release_name}-api-server.${var.namespace}.svc.cluster.local"
            port = { number = 8080 }
          }
        }]
      }]
    }
  }

  depends_on = [helm_release.airflow]
}

output "airflow_url" {
  value = local.base_url
}

output "oidc_callback_url" {
  value = local.callback_url
}
