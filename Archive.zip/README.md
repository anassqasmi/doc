# MLflow on Kubernetes (Helm + Istio + Terraform)

A configurable Helm chart that deploys the MLflow tracking server for ML use
cases, secured and exposed through Istio, plus a Terraform module and a local
kind test harness.

## What gets deployed

- **MLflow tracking server** (`Deployment` + `Service` + `ServiceAccount`).
- **Backend store**: external Cloud SQL (Postgres) for production, or a
  removable SQLite + PVC path for local testing.
- **Artifact store**: GCS bucket for production (via Workload Identity), or a
  local PVC for testing. Served through the tracking server (proxied artifacts).
- **Istio networking**: `Gateway`, `VirtualService`, `AuthorizationPolicy`,
  `RequestAuthentication` (OIDC-JWT SSO), `PeerAuthentication` (mTLS).
- **`NetworkPolicy`** (default-deny with explicit ingress/egress allows).
- **`ConfigMap`** carrying MLflow server settings.

```
charts/mlflow/        # the Helm chart
  values.yaml         # production defaults, every knob exposed
  values-local.yaml   # local kind overrides (SQLite + relaxed SSO) -- remove for prod
terraform/            # helm_release + provider wiring
docker/Dockerfile     # prod image with psycopg2 + google-cloud-storage
scripts/              # kind cluster + Istio + deploy for local testing
```

## Quick start (local kind test)

```bash
./scripts/deploy-local.sh
# ... test ...
./scripts/teardown.sh
```

This creates a kind cluster, installs Istio (ingress gateway on
`localhost:8080`), and installs the chart with `values-local.yaml`
(SQLite backend, local PVC artifacts, SSO disabled so the UI is reachable).

Deploy via Terraform instead of Helm:

```bash
USE_TERRAFORM=1 ./scripts/deploy-local.sh
```

Verify:

```bash
curl -H "Host: mlflow.local" http://localhost:8080/health
```

## Production deployment

1. Build and push the production image (bundles Postgres + GCS drivers):

```bash
docker build -t REGION-docker.pkg.dev/PROJECT/REPO/mlflow:2.14.1 docker/
docker push REGION-docker.pkg.dev/PROJECT/REPO/mlflow:2.14.1
```

2. Pre-create the DB credentials Secret in the target namespace:

```bash
kubectl -n mlflow create secret generic mlflow-cloudsql \
  --from-literal=username=mlflow --from-literal=password=CHANGE_ME
```

3. Deploy with Terraform (SQLite path removed automatically when
   `local_test=false`):

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars   # then edit
terraform init
terraform apply -var="local_test=false"
```

Or with Helm directly (production values only, no `values-local.yaml`):

```bash
helm upgrade --install mlflow charts/mlflow -n mlflow --create-namespace \
  --set image.repository=REGION-docker.pkg.dev/PROJECT/REPO/mlflow \
  --set image.tag=2.14.1 \
  --set backendStore.postgres.host=10.20.30.40 \
  --set backendStore.postgres.existingSecret.name=mlflow-cloudsql \
  --set server.artifactsDestination=gs://my-bucket/mlflow \
  --set 'serviceAccount.annotations.iam\.gke\.io/gcp-service-account=mlflow@PROJECT.iam.gserviceaccount.com' \
  --set istio.auth.issuer=https://accounts.google.com \
  --set 'istio.auth.audiences={my-client-id}' \
  --set 'istio.gateway.hosts={mlflow.mycompany.com}'
```

## The "test line" (SQLite) to remove for prod

Backend selection lives in `values-local.yaml`:

```yaml
backendStore:
  type: sqlite            # <- switch to postgres (or just drop values-local.yaml) for prod
  sqlite:
    path: "/mlflow/store/mlflow.db"
```

Stop passing `values-local.yaml` (or set `backendStore.type=postgres`) and the
chart uses the Cloud SQL configuration from `values.yaml`.

## Authentication

Three independent options (pick what you need):

### 1. OIDC SSO via oauth2-proxy (recommended for real SSO, e.g. Okta)

MLflow has no native OIDC, so `oauth2-proxy` sits in front of it and performs
the interactive OIDC login redirect. All ingress traffic is forced through the
Istio gateway and then through oauth2-proxy:

```
browser -> Istio ingress gateway -> oauth2-proxy (OIDC login) -> MLflow
```

Istio authorization guarantees there is **no other way in**:

- MLflow's `AuthorizationPolicy` allows only the oauth2-proxy workload identity
  (`cluster.local/ns/<ns>/sa/<release>-oauth2-proxy`). Direct service access,
  port-forwards, and other pods get `403` (verified).
- oauth2-proxy's `AuthorizationPolicy` allows only the Istio ingress gateway
  identity, so requests must enter through the gateway.
- A namespace-wide `PeerAuthentication` (`mtlsMode: STRICT`) enforces mTLS so
  those workload identities are real.

Enable it with the OIDC overlay and your Okta app details:

```bash
helm upgrade --install mlflow charts/mlflow -n mlflow \
  -f charts/mlflow/values-local.yaml \
  -f charts/mlflow/values-oidc.yaml \
  --set oauth2Proxy.oidcIssuerUrl=https://<org>.okta.com/oauth2/default \
  --set oauth2Proxy.clientID=<okta-client-id> \
  --set oauth2Proxy.clientSecret=<okta-client-secret> \
  --set 'oauth2Proxy.redirectUrl=http://mlflow.local:8080/oauth2/callback'
```

In your Okta OIDC (Web) app, register the redirect URI
`http://mlflow.local:8080/oauth2/callback` (use your real host/scheme in prod).
oauth2-proxy stays `NotReady` until `oidcIssuerUrl`/client credentials are valid
(OIDC discovery must succeed at startup).

Config lives under `oauth2Proxy` in `values.yaml` (issuer, client id/secret or
`existingSecret`, `cookieSecret`, `scope`, `emailDomains`, `extraArgs`, ...).

### 2. App-level login + profile (MLflow basic-auth)

`basicAuth.enabled` turns on MLflow's native username/password auth. This is
what gives you an actual **login prompt** in the browser and a **user/profile +
permissions** view inside the MLflow UI. It works with no external IdP, so it is
enabled in `values-local.yaml`:

```yaml
basicAuth:
  enabled: true
  adminUsername: "admin"
  adminPassword: "password"   # rendered into a Secret
  defaultPermission: "READ"
  dataDir: "/mlflow/auth"      # sqlite auth DB on the PVC (local)
```

- Log in at the browser prompt with `admin` / `password`.
- Create more users at `/signup` or via `/api/2.0/mlflow/users/*`.
- `/health` stays unauthenticated so the k8s probes keep working.
- For production/multi-replica, set `basicAuth.databaseUri` to a Postgres URL
  (sqlite doesn't work across replicas) and set a stable `basicAuth.flaskSecretKey`.
- Clients authenticate with `MLFLOW_TRACKING_USERNAME` / `MLFLOW_TRACKING_PASSWORD`.

### 3. Mesh-edge SSO (Istio OIDC-JWT)

`istio.auth.enabled` toggles OIDC-JWT enforcement at the Istio edge
(`RequestAuthentication` validates the token, `AuthorizationPolicy` requires
it). It only *validates* a bearer token already on the request; it does **not**
provide a login screen (that's what option 1 / oauth2-proxy is for). Use this
for machine-to-machine API access with pre-obtained tokens. Not used when
`oauth2Proxy.enabled=true`.
