# MLflow on Kubernetes (Helm + Istio + Terraform)

A configurable Helm chart that deploys the MLflow tracking server for ML use
cases, secured and exposed through Istio, plus a Terraform module and a local
kind test harness.

## What gets deployed

- **MLflow tracking server** (`Deployment` + `Service` + `ServiceAccount`).
- **Backend store**: external Cloud SQL (Postgres) for production, or a
  removable SQLite + PVC path for local testing.
- **Artifact store**: GCS bucket for production (via Workload Identity), or a
  local PVC for testing. Served through the tracking server (proxied artifacts).
- **Istio networking**: `Gateway`, `VirtualService`, `AuthorizationPolicy`,
  `RequestAuthentication` (OIDC-JWT SSO), `PeerAuthentication` (mTLS).
- **`NetworkPolicy`** (default-deny with explicit ingress/egress allows).
- **`ConfigMap`** carrying MLflow server settings.

```
charts/mlflow/        # the Helm chart
  values.yaml         # production defaults, every knob exposed
  values-local.yaml   # local kind overrides (SQLite + relaxed SSO) -- remove for prod
terraform/            # helm_release + provider wiring
docker/Dockerfile     # prod image with psycopg2 + google-cloud-storage
scripts/              # kind cluster + Istio + deploy for local testing
```

## Quick start (local kind test)

```bash
./scripts/deploy-local.sh
# ... test ...
./scripts/teardown.sh
```

This creates a kind cluster, installs Istio (ingress gateway on
`localhost:8080`), and installs the chart with `values-local.yaml`
(SQLite backend, local PVC artifacts, SSO disabled so the UI is reachable).

Deploy via Terraform instead of Helm:

```bash
USE_TERRAFORM=1 ./scripts/deploy-local.sh
```

Verify:

```bash
curl -H "Host: mlflow.local" http://localhost:8080/health
```

## Production deployment

1. Build and push the production image (bundles Postgres + GCS drivers):

```bash
docker build -t REGION-docker.pkg.dev/PROJECT/REPO/mlflow:2.14.1 docker/
docker push REGION-docker.pkg.dev/PROJECT/REPO/mlflow:2.14.1
```

2. Pre-create the DB credentials Secret in the target namespace:

```bash
kubectl -n mlflow create secret generic mlflow-cloudsql \
  --from-literal=username=mlflow --from-literal=password=CHANGE_ME
```

3. Deploy with Terraform (SQLite path removed automatically when
   `local_test=false`):

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars   # then edit
terraform init
terraform apply -var="local_test=false"
```

Or with Helm directly (production values only, no `values-local.yaml`):

```bash
helm upgrade --install mlflow charts/mlflow -n mlflow --create-namespace \
  --set image.repository=REGION-docker.pkg.dev/PROJECT/REPO/mlflow \
  --set image.tag=2.14.1 \
  --set backendStore.postgres.host=10.20.30.40 \
  --set backendStore.postgres.existingSecret.name=mlflow-cloudsql \
  --set server.artifactsDestination=gs://my-bucket/mlflow \
  --set 'serviceAccount.annotations.iam\.gke\.io/gcp-service-account=mlflow@PROJECT.iam.gserviceaccount.com' \
  --set istio.auth.issuer=https://accounts.google.com \
  --set 'istio.auth.audiences={my-client-id}' \
  --set 'istio.gateway.hosts={mlflow.mycompany.com}'
```

## The "test line" (SQLite) to remove for prod

Backend selection lives in `values-local.yaml`:

```yaml
backendStore:
  type: sqlite            # <- switch to postgres (or just drop values-local.yaml) for prod
  sqlite:
    path: "/mlflow/store/mlflow.db"
```

Stop passing `values-local.yaml` (or set `backendStore.type=postgres`) and the
chart uses the Cloud SQL configuration from `values.yaml`.

## SSO / auth notes

`istio.auth.enabled` toggles OIDC-JWT enforcement at the mesh edge
(`RequestAuthentication` validates the token, `AuthorizationPolicy` requires
it). It is `false` in `values-local.yaml` because kind has no real IdP; set the
`issuer`, `jwksUri`, and `audiences` and enable it for production.
