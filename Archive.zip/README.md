# Airflow 3 on GKE — first step

Airflow 3.2.2 from the official Helm chart (1.22.0), vendored in `chart/` with the
Bitnami PostgreSQL dependency and every unused component removed. One pod, no
persistent volumes, SQLite metadata DB, OIDC login, exposed through an existing
Istio gateway.

Airflow 3 removed `SequentialExecutor` — it rewrites the value to `LocalExecutor`
at startup — so the chart is configured with `LocalExecutor`, which is what runs
against SQLite now.

## Files

| File | Purpose |
| --- | --- |
| `main.tf` | Variables, metadata-connection secret, `helm_release` on `./chart`, Istio `VirtualService` |
| `webserver_config.py` | FAB auth manager OIDC config, mounted into the API server |
| `chart/` | Vendored Airflow chart, no remote dependencies |

## Usage

Add the module to a root config that already has the `helm` and `kubernetes` providers:

```hcl
module "airflow" {
  source           = "./airflow"
  namespace        = "data"
  hostname         = "airflow.example.com"
  istio_gateway    = "istio-system/public-gateway"
  oidc_issuer_url  = "https://idp.example.com/realms/main"
  oidc_secret_name = "airflow-oidc"
}
```

Register `module.airflow.oidc_callback_url` (`https://<hostname>/auth/oauth-authorized/oidc`)
as a redirect URI in the IdP. The existing secret must have `client-id` and
`client-secret` keys; it is read, never created.

## Local test

`test/kind.sh` builds a throwaway kind cluster with the pieces the module assumes
already exist — Istio plus the `istio-system/public-gateway`, Dex as the OIDC
provider, the namespace and the `airflow-oidc` secret — then applies the module
against it through `test/main.tf`.

```bash
./test/kind.sh          # up, prints the URL
./test/kind.sh down     # delete the cluster
```

Airflow lands on <http://airflow.localtest.me:8080> (that domain resolves to
127.0.0.1, and the cluster maps host port 8080 to the ingress gateway); log in with
`admin@example.com` / `password`. The gateway uses 8080 on both sides so the IdP has
a single URL valid for the browser and for the pods. Everything is HTTP locally, so
the test sets `public_url` accordingly and the `X-Forwarded-Proto: https` path is not
exercised.

## What gets deployed

One Deployment, one Service, one ServiceAccount, two ConfigMaps and the three secrets
the chart generates (fernet key, API secret key, JWT secret). The pod holds:

- `db-migrate` init container — `airflow db migrate` against the empty SQLite file
- `api-server` — serves the UI and the execution API, with `--proxy-headers`
- `scheduler` and `dag-processor` sidecars

## Notes

- Storage is entirely ephemeral. The SQLite file lives on an `emptyDir` at
  `/opt/airflow/metadata`, so **the whole metadata DB is lost on every restart** —
  DAG history, users, connections. SQLite is also single-writer, which is why the
  three components share one pod rather than being separate Deployments. Cloud SQL
  is the next step.
- Logs stay on stdout for Cloud Logging to collect; no log PVC, no Elasticsearch or
  OpenSearch. Task log retrieval in the UI is limited to what is on local disk.
- The chart's default `core.execution_api_server_url` already points at the
  in-cluster Service, so scheduler-to-API traffic does not leave the cluster.
- Every OIDC user gets `Admin` (`OIDC_DEFAULT_ROLE`); real RBAC comes later.
- The image must include `apache-airflow-providers-fab` (the default
  `apache/airflow:3.2.2` image does).
- Removed from the vendored chart: postgresql, redis, pgbouncer, statsd,
  otel-collector, flower, workers, triggerer, the 2.x webserver, cleanup and
  database-cleanup cronjobs, the migrate/create-user jobs, RBAC for pod launching,
  priority classes, the DAG and log PVCs, limit ranges, resource quotas, HPA,
  PDB, NetworkPolicy and Ingress.
