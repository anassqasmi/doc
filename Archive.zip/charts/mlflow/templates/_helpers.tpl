{{/*
Expand the name of the chart.
*/}}
{{- define "mlflow.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "mlflow.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "mlflow.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "mlflow.labels" -}}
helm.sh/chart: {{ include "mlflow.chart" . }}
{{ include "mlflow.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: mlflow
{{- end }}

{{/*
Selector labels
*/}}
{{- define "mlflow.selectorLabels" -}}
app.kubernetes.io/name: {{ include "mlflow.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
ServiceAccount name.
*/}}
{{- define "mlflow.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "mlflow.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Gateway name.
*/}}
{{- define "mlflow.gatewayName" -}}
{{- default (printf "%s-gateway" (include "mlflow.fullname" .)) .Values.istio.gateway.name }}
{{- end }}

{{/*
Name of the Secret holding backend DB credentials (postgres path).
*/}}
{{- define "mlflow.dbSecretName" -}}
{{- if .Values.backendStore.postgres.existingSecret.name }}
{{- .Values.backendStore.postgres.existingSecret.name }}
{{- else }}
{{- printf "%s-db" (include "mlflow.fullname" .) }}
{{- end }}
{{- end }}

{{/*
oauth2-proxy resource name.
*/}}
{{- define "mlflow.oauth2ProxyName" -}}
{{- printf "%s-oauth2-proxy" (include "mlflow.fullname" .) }}
{{- end }}

{{/*
oauth2-proxy selector labels.
*/}}
{{- define "mlflow.oauth2ProxySelectorLabels" -}}
app.kubernetes.io/name: {{ include "mlflow.name" . }}-oauth2-proxy
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: oauth2-proxy
{{- end }}

{{/*
Name of the Secret holding oauth2-proxy credentials.
*/}}
{{- define "mlflow.oauth2ProxySecretName" -}}
{{- if .Values.oauth2Proxy.existingSecret }}
{{- .Values.oauth2Proxy.existingSecret }}
{{- else }}
{{- printf "%s-oauth2-proxy" (include "mlflow.fullname" .) }}
{{- end }}
{{- end }}

{{/*
SPIFFE principal of the fronting oauth2-proxy (used in mlflow AuthorizationPolicy).
*/}}
{{- define "mlflow.oauth2ProxyPrincipal" -}}
{{- printf "cluster.local/ns/%s/sa/%s" .Release.Namespace (include "mlflow.oauth2ProxyName" .) }}
{{- end }}

{{/*
SPIFFE principal of the Istio ingress gateway.
*/}}
{{- define "mlflow.ingressGatewayPrincipal" -}}
{{- printf "cluster.local/ns/%s/sa/%s" .Values.istio.ingressGateway.namespace .Values.istio.ingressGateway.serviceAccount }}
{{- end }}

{{/*
Host the Istio VirtualService routes to (oauth2-proxy when enabled, else mlflow).
*/}}
{{- define "mlflow.ingressDestinationHost" -}}
{{- if .Values.oauth2Proxy.enabled }}
{{- printf "%s.%s.svc.cluster.local" (include "mlflow.oauth2ProxyName" .) .Release.Namespace }}
{{- else }}
{{- printf "%s.%s.svc.cluster.local" (include "mlflow.fullname" .) .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Port the Istio VirtualService routes to.
*/}}
{{- define "mlflow.ingressDestinationPort" -}}
{{- if .Values.oauth2Proxy.enabled }}{{ .Values.oauth2Proxy.service.port }}{{- else }}{{ .Values.service.port }}{{- end }}
{{- end }}

{{/*
Basic-auth users/permissions DB URI (defaults to sqlite in dataDir).
*/}}
{{- define "mlflow.authDbUri" -}}
{{- if .Values.basicAuth.databaseUri }}
{{- .Values.basicAuth.databaseUri }}
{{- else }}
{{- printf "sqlite:///%s/basic_auth.db" .Values.basicAuth.dataDir }}
{{- end }}
{{- end }}

{{/*
VirtualService host list (defaults to gateway hosts).
*/}}
{{- define "mlflow.vsHosts" -}}
{{- if .Values.istio.virtualService.hosts }}
{{- toYaml .Values.istio.virtualService.hosts }}
{{- else }}
{{- toYaml .Values.istio.gateway.hosts }}
{{- end }}
{{- end }}
