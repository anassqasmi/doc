{{/*
Expand the name of the chart.
*/}}
{{- define "mlflow.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "mlflow.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "mlflow.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "mlflow.labels" -}}
helm.sh/chart: {{ include "mlflow.chart" . }}
{{ include "mlflow.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: mlflow
{{- end }}

{{/*
Selector labels
*/}}
{{- define "mlflow.selectorLabels" -}}
app.kubernetes.io/name: {{ include "mlflow.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
ServiceAccount name.
*/}}
{{- define "mlflow.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "mlflow.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Gateway name.
*/}}
{{- define "mlflow.gatewayName" -}}
{{- default (printf "%s-gateway" (include "mlflow.fullname" .)) .Values.istio.gateway.name }}
{{- end }}

{{/*
Name of the Secret holding backend DB credentials (postgres path).
*/}}
{{- define "mlflow.dbSecretName" -}}
{{- if .Values.backendStore.postgres.existingSecret.name }}
{{- .Values.backendStore.postgres.existingSecret.name }}
{{- else }}
{{- printf "%s-db" (include "mlflow.fullname" .) }}
{{- end }}
{{- end }}

{{/*
VirtualService host list (defaults to gateway hosts).
*/}}
{{- define "mlflow.vsHosts" -}}
{{- if .Values.istio.virtualService.hosts }}
{{- toYaml .Values.istio.virtualService.hosts }}
{{- else }}
{{- toYaml .Values.istio.gateway.hosts }}
{{- end }}
{{- end }}
