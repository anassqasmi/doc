output "namespace" {
  description = "Namespace MLflow is deployed into."
  value       = kubernetes_namespace.mlflow.metadata[0].name
}

output "release_name" {
  description = "Helm release name."
  value       = helm_release.mlflow.name
}

output "release_status" {
  description = "Helm release status."
  value       = helm_release.mlflow.status
}
