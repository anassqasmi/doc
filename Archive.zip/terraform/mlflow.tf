# Deploys the local mlflow Helm chart via the helm provider.
#
#   Local kind test:  terraform apply            (local_test defaults to true)
#   Production:       terraform apply -var="local_test=false" -var-file=prod.tfvars

locals {
  # Production overrides (only used when local_test = false).
  prod_overrides = {
    namespace    = var.namespace
    replicaCount = 2
    image = {
      repository = var.image_repository
      tag        = var.image_tag
    }
    server = {
      artifactsDestination = var.artifacts_destination
    }
    backendStore = {
      type = "postgres"
      postgres = {
        host     = var.postgres_host
        database = var.postgres_database
        existingSecret = {
          name = var.db_existing_secret
        }
      }
    }
    serviceAccount = {
      create = true
      name   = var.release_name
      annotations = var.gcp_service_account == "" ? {} : {
        "iam.gke.io/gcp-service-account" = var.gcp_service_account
      }
    }
    istio = {
      gateway = {
        hosts = var.gateway_hosts
      }
      virtualService = {
        hosts = var.gateway_hosts
      }
      auth = {
        enabled   = true
        issuer    = var.oidc_issuer
        jwksUri   = var.oidc_jwks_uri
        audiences = var.oidc_audiences
      }
    }
  }

  # Local overrides layered on top of values-local.yaml.
  local_overrides = {
    image = {
      repository = var.image_repository
      tag        = var.image_tag
    }
  }

  overrides = var.local_test ? local.local_overrides : local.prod_overrides
}

# Namespace managed here so we can add the Istio sidecar-injection label.
resource "kubernetes_namespace" "mlflow" {
  metadata {
    name = var.namespace
    labels = {
      "istio-injection" = "enabled"
    }
  }
}

resource "helm_release" "mlflow" {
  name             = var.release_name
  namespace        = kubernetes_namespace.mlflow.metadata[0].name
  create_namespace = false
  chart            = var.chart_path

  dependency_update = false
  atomic            = true
  timeout           = 600
  wait              = true

  values = concat(
    var.local_test ? [file("${var.chart_path}/values-local.yaml")] : [],
    [yamlencode(local.overrides)],
  )
}
