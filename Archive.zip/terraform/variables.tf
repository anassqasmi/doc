variable "kubeconfig" {
  description = "Path to the kubeconfig file."
  type        = string
  default     = "~/.kube/config"
}

variable "kube_context" {
  description = "Kube context to target (kind-mlflow for the local test cluster)."
  type        = string
  default     = "kind-mlflow"
}

variable "namespace" {
  description = "Namespace to deploy MLflow into."
  type        = string
  default     = "mlflow"
}

variable "release_name" {
  description = "Helm release name."
  type        = string
  default     = "mlflow"
}

variable "chart_path" {
  description = "Path to the local mlflow chart."
  type        = string
  default     = "../charts/mlflow"
}

variable "local_test" {
  description = "When true, apply values-local.yaml (SQLite + relaxed SSO) for kind testing."
  type        = bool
  default     = true
}

variable "image_repository" {
  description = "MLflow image repository."
  type        = string
  default     = "ghcr.io/mlflow/mlflow"
}

variable "image_tag" {
  description = "MLflow image tag."
  type        = string
  default     = "v2.14.1"
}

# --- Production backend / artifact settings (ignored when local_test = true) ---
variable "postgres_host" {
  description = "Cloud SQL Postgres host."
  type        = string
  default     = ""
}

variable "postgres_database" {
  description = "Cloud SQL database name."
  type        = string
  default     = "mlflow"
}

variable "db_existing_secret" {
  description = "Name of an existing Secret with DB username/password."
  type        = string
  default     = ""
}

variable "artifacts_destination" {
  description = "Artifact store destination (gs://bucket/path)."
  type        = string
  default     = ""
}

variable "oidc_issuer" {
  description = "OIDC issuer URL for SSO."
  type        = string
  default     = "https://accounts.google.com"
}

variable "oidc_jwks_uri" {
  description = "OIDC JWKS URI."
  type        = string
  default     = "https://www.googleapis.com/oauth2/v3/certs"
}

variable "oidc_audiences" {
  description = "Accepted OIDC audiences (client IDs)."
  type        = list(string)
  default     = []
}

variable "gateway_hosts" {
  description = "Hostnames served by the Istio gateway/virtualservice."
  type        = list(string)
  default     = ["mlflow.example.com"]
}

variable "gcp_service_account" {
  description = "GCP service account for Workload Identity (GCS access). Empty to skip annotation."
  type        = string
  default     = ""
}
