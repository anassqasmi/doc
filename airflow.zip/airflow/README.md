# Airflow 3 on GKE

Official Helm chart **1.22.0** (Airflow **3.2.2**), vendored in `chart/` with the
Bitnami PostgreSQL subchart removed. External Cloud SQL via an **existing**
metadata secret, LocalExecutor, OIDC login, Istio gateway, GCS DAGs via the
GKE Cloud Storage FUSE CSI driver.

The module does **not** create the Postgres instance, the metadata secret, or
the `airflow` ServiceAccount (Workload Identity must already be bound to that SA).

## Usage

```hcl
module "airflow" {
  source = "./airflow"

  namespace           = "data"
  airflow_hostname    = "portal.example.com"
  url_path            = "/airflow"
  airflow_public_url  = "https://portal.example.com/airflow"
  istio_gateway       = "istio-system/public-gateway"
  oidc_issuer_url     = "https://idp.example.com/realms/main"
  oidc_secret_name    = "airflow-oidc"
  airflow_service_account = "airflow"

  # Existing secret — key "connection" must be a SQLAlchemy URL:
  # postgresql+psycopg2://user:pass@host:5432/airflow?sslmode=require
  metadata_db_secret_name = "airflow-metadata-connection"

  dags_bucket_name  = "my-airflow-dags-bucket"
  dags_custom_path  = "~/dags" # mounted at /home/airflow/dags
}
```

`~/dags` is expanded to `/home/airflow/dags` (Kubernetes does not expand `~`).

## Local test

```bash
./test/kind.sh          # Istio + Dex + Postgres + metadata secret + Airflow
./test/kind.sh down
```

UI: <http://airflow.localtest.me:8080/airflow> — `admin@example.com` / `password`.
GCS is skipped in Kind (no CSI driver).
