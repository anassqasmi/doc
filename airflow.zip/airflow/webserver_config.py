import os
import ssl

# IdP often presents an internal/private CA; skip TLS verify for OIDC HTTP calls.
ssl._create_default_https_context = ssl._create_unverified_context

import jwt
from flask import flash, g, redirect, request, session, url_for
from flask_appbuilder._compat import as_unicode
from flask_appbuilder.security.utils import generate_random_string
from flask_appbuilder.views import expose

from airflow.providers.fab.auth_manager.security_manager.override import (
    FabAirflowSecurityManagerOverride,
)
from airflow.providers.fab.auth_manager.views.auth_oauth import CustomAuthOAuthView
from flask_appbuilder.security.manager import AUTH_OAUTH

AUTH_TYPE = AUTH_OAUTH
AUTH_USER_REGISTRATION = True
AUTH_USER_REGISTRATION_ROLE = os.environ.get("OIDC_DEFAULT_ROLE", "Admin")

AUTH_ROLES_SYNC_AT_LOGIN = True

AUTH_ROLES_MAPPING = {
    "airflow-admin": ["Admin"],
    "airflow-op": ["Op"],
    "airflow-user": ["User"],
    "airflow-viewer": ["Viewer"],
}

OAUTH_PROVIDERS = [
    {
        "name": "oidc",
        "icon": "fa-key",
        "token_key": "access_token",
        "remote_app": {
            "client_id": os.environ["OIDC_CLIENT_ID"],
            "client_secret": os.environ["OIDC_CLIENT_SECRET"],
            "server_metadata_url": os.environ["OIDC_ISSUER_URL"].rstrip("/")
            + "/.well-known/openid-configuration",
            "client_kwargs": {
                "scope": "openid email profile",
                "verify": False,
            },
        },
    }
]


class OidcAuthOAuthView(CustomAuthOAuthView):
    """FAB ignores remote_app redirect_uri; force OIDC_CALLBACK_URL on authorize."""

    @expose("/login/")
    @expose("/login/<provider>")
    def login(self, provider=None):
        if g.user is not None and g.user.is_authenticated:
            return redirect(self.appbuilder.get_url_for_index)

        if provider is None:
            return self.render_template(
                self.login_template,
                providers=self.appbuilder.sm.oauth_providers,
                title=self.title,
                appbuilder=self.appbuilder,
            )

        random_state = generate_random_string()
        state = jwt.encode(request.args.to_dict(flat=False), random_state, algorithm="HS256")
        session["oauth_state"] = random_state

        redirect_uri = os.environ.get("OIDC_CALLBACK_URL") or url_for(
            ".oauth_authorized", provider=provider, _external=True
        )

        try:
            return self.appbuilder.sm.oauth_remotes[provider].authorize_redirect(
                redirect_uri=redirect_uri,
                state=state.decode("ascii") if isinstance(state, bytes) else state,
            )
        except Exception:
            flash(as_unicode(self.invalid_login_message), "warning")
            return redirect(self.appbuilder.get_url_for_index)


class OidcSecurityManager(FabAirflowSecurityManagerOverride):
    """Maps OIDC claims onto FAB users; uses fixed callback URL when configured."""

    authoauthview = OidcAuthOAuthView

    def get_oauth_user_info(self, provider, resp=None):
        me = self.appbuilder.sm.oauth_remotes[provider].userinfo()
        role_keys = (
            me.get("roles")
            or me.get("groups")
            or me.get("realm_access", {}).get("roles")
            or []
        )
        return {
            "username": me.get("preferred_username") or me.get("email") or me["sub"],
            "email": me.get("email"),
            "first_name": me.get("given_name", ""),
            "last_name": me.get("family_name", ""),
            "role_keys": role_keys,
        }


SECURITY_MANAGER_CLASS = OidcSecurityManager
