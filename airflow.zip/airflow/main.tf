variable "namespace" {
  description = "Existing namespace to deploy Airflow into."
  type        = string
}

variable "airflow_release_name" {
  description = "Helm release name."
  type        = string
  default     = "airflow"
}

variable "airflow_hostname" {
  description = "Public hostname served by the Istio gateway."
  type        = string
}

variable "istio_gateway" {
  description = "Existing Istio Gateway, as namespace/name."
  type        = string
  default     = "istio-system/public-gateway"
}

variable "oidc_issuer_url" {
  description = "OIDC issuer URL (discovery document is derived from it)."
  type        = string
}

variable "oidc_secret_name" {
  description = "Existing secret holding the OIDC credentials (keys: client-id, client-secret)."
  type        = string
}

variable "oidc_callback_url" {
  description = "Redirect URI registered in the IdP. Defaults to <public_url>/auth/oauth-authorized/oidc."
  type        = string
  default     = null
}

variable "airflow_image" {
  description = "Airflow image used by every container in the pod."
  type        = string
  default     = "apache/airflow:3.2.2"
}

variable "airflow_public_url" {
  description = "Full public URL including path if any (e.g. https://host/airflow). Overrides hostname+url_path."
  type        = string
  default     = null
}

variable "url_path" {
  description = "Path prefix on the host (e.g. /airflow). Must match api.base_url. Empty = host root."
  type        = string
  default     = ""
}

variable "metadata_db_secret_name" {
  description = "Existing secret with key 'connection' (SQLAlchemy URL, e.g. postgresql+psycopg2://...)."
  type        = string
}

variable "airflow_service_account" {
  description = "Existing Kubernetes ServiceAccount (Workload Identity) used by all Airflow pods."
  type        = string
  default     = "airflow"
}

variable "dags_bucket_name" {
  description = "GCS bucket mounted as the DAGs volume via the GKE GCS FUSE CSI driver. Empty skips the mount."
  type        = string
  default     = ""
}

variable "dags_custom_path" {
  description = "Mount path for the DAGs GCS bucket. ~/ is expanded to /home/airflow/."
  type        = string
  default     = "~/dags"
}

locals {
  url_path = trimsuffix(var.url_path == "/" ? "" : var.url_path, "/")
  base_url = trimsuffix(
    coalesce(var.airflow_public_url, "https://${var.airflow_hostname}${local.url_path}"),
    "/",
  )
  path = (
    local.url_path != ""
    ? local.url_path
    : try(trimsuffix(regex("https?://[^/]+(/.*)$", local.base_url), "/"), "")
  )
  callback_url = coalesce(var.oidc_callback_url, "${local.base_url}/auth/oauth-authorized/oidc")

  dest = {
    host = "${var.airflow_release_name}-api-server.${var.namespace}.svc.cluster.local"
    port = { number = 8080 }
  }

  # If path=/airflow: redirect / → /airflow/, route /airflow/** as-is (no strip).
  vs_http = yamldecode(local.path == "" ? yamlencode([{
    route = [{ destination = local.dest }]
    }]) : yamlencode([
    {
      match    = [{ uri = { exact = "/" } }]
      redirect = { uri = "${local.path}/" }
    },
    {
      match    = [{ uri = { exact = local.path } }]
      redirect = { uri = "${local.path}/" }
    },
    {
      match = [{ uri = { prefix = "${local.path}/" } }]
      route = [{ destination = local.dest }]
    },
  ]))

  # Kubernetes cannot mount "~/dags"; Airflow image HOME is /home/airflow.
  dags_mount_path = (
    startswith(var.dags_custom_path, "~/")
    ? "/home/airflow/${trimprefix(var.dags_custom_path, "~/")}"
    : var.dags_custom_path
  )

  existing_sa = {
    create = false
    name   = var.airflow_service_account
  }

  dags_gcs_volume = {
    name = "dags-gcs"
    csi = {
      driver = "gcsfuse.csi.storage.gke.io"
      volumeAttributes = {
        bucketName   = var.dags_bucket_name
        mountOptions = "implicit-dirs,uid=50000,gid=0"
      }
    }
  }

  dags_gcs_mount = {
    name      = "dags-gcs"
    mountPath = local.dags_mount_path
    readOnly  = true
  }

  gcsfuse_pod = {
    extraVolumes      = [local.dags_gcs_volume]
    extraVolumeMounts = [local.dags_gcs_mount]
    podAnnotations    = { "gke-gcsfuse/volumes" = "true" }
  }

  image_parts = split(":", var.airflow_image)
}

resource "helm_release" "airflow" {
  name            = var.airflow_release_name
  chart           = "${path.module}/chart"
  namespace       = var.namespace
  timeout         = 900
  force_update    = true
  cleanup_on_fail = true
  upgrade_install = true

  values = [yamlencode(merge(
    {
      executor   = "LocalExecutor"
      images     = { airflow = { repository = local.image_parts[0], tag = local.image_parts[1] } }
      postgresql = { enabled = false }
      redis      = { enabled = false }
      statsd     = { enabled = false }

      data = { metadataSecretName = var.metadata_db_secret_name }

      config = {
        api  = { base_url = local.base_url }
        core = { auth_manager = "airflow.providers.fab.auth_manager.fab_auth_manager.FabAuthManager" }
      }

      createUserJob      = { enabled = false, serviceAccount = local.existing_sa }
      migrateDatabaseJob = { serviceAccount = local.existing_sa }

      apiServer = merge(
        {
          args            = ["bash", "-c", "exec airflow api-server --proxy-headers"]
          serviceAccount  = local.existing_sa
          apiServerConfig = file("${path.module}/webserver_config.py")
          env = [
            { name = "FORWARDED_ALLOW_IPS", value = "*" },
            { name = "OIDC_ISSUER_URL", value = var.oidc_issuer_url },
            { name = "OIDC_CALLBACK_URL", value = local.callback_url },
            { name = "OIDC_CLIENT_ID", valueFrom = { secretKeyRef = { name = var.oidc_secret_name, key = "client-id" } } },
            { name = "OIDC_CLIENT_SECRET", valueFrom = { secretKeyRef = { name = var.oidc_secret_name, key = "client-secret" } } },
          ]
        },
        var.dags_bucket_name != "" ? local.gcsfuse_pod : {},
      )

      scheduler = merge(
        { serviceAccount = local.existing_sa },
        var.dags_bucket_name != "" ? local.gcsfuse_pod : {},
      )

      dagProcessor = merge(
        { serviceAccount = local.existing_sa },
        var.dags_bucket_name != "" ? local.gcsfuse_pod : {},
      )

      triggerer = merge(
        { serviceAccount = local.existing_sa },
        var.dags_bucket_name != "" ? local.gcsfuse_pod : {},
      )
    },
    var.dags_bucket_name != "" ? { dags = { mountPath = local.dags_mount_path } } : {},
  ))]
}

resource "kubernetes_manifest" "virtual_service" {
  manifest = {
    apiVersion = "networking.istio.io/v1"
    kind       = "VirtualService"
    metadata = {
      name      = var.airflow_release_name
      namespace = var.namespace
    }
    spec = {
      hosts    = [var.airflow_hostname]
      gateways = [var.istio_gateway]
      http     = local.vs_http
    }
  }

  depends_on = [helm_release.airflow]
}

output "airflow_url" {
  value = local.base_url
}

output "oidc_callback_url" {
  value = local.callback_url
}

output "dags_mount_path" {
  value = local.dags_mount_path
}
